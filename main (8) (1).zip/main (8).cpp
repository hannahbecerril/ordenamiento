#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

// Estructura para almacenar los registros de la bitácora
struct Registro {
  string mes;
  int dia;
  string hora;
  string ip;
  string razon;

  // Función para convertir el mes en número
  int mesANumero() const {
    if (mes == "Jan")
      return 1;
    if (mes == "Feb")
      return 2;
    if (mes == "Mar")
      return 3;
    if (mes == "Apr")
      return 4;
    if (mes == "May")
      return 5;
    if (mes == "Jun")
      return 6;
    if (mes == "Jul")
      return 7;
    if (mes == "Aug")
      return 8;
    if (mes == "Sep")
      return 9;
    if (mes == "Oct")
      return 10;
    if (mes == "Nov")
      return 11;
    if (mes == "Dec")
      return 12;
    return 0; // por defecto
  }

  // Sobrecargar el operador < para ordenar por fecha
  bool operator<(Registro otro) const {
    if (mesANumero() != otro.mesANumero())
      return mesANumero() < otro.mesANumero();
    if (dia != otro.dia)
      return dia < otro.dia;
    return hora < otro.hora;
  }

  // Sobrecarga de los operadores >= y <= para comparar fechas
  bool operator>=(Registro otro) const {
    if (mesANumero() > otro.mesANumero())
      return true;
    if (mesANumero() == otro.mesANumero() && dia > otro.dia)
      return true;
    if (mesANumero() == otro.mesANumero() && dia == otro.dia &&
        hora >= otro.hora)
      return true;
    return false;
  }

  bool operator<=(Registro otro) const {
    if (mesANumero() < otro.mesANumero())
      return true;
    if (mesANumero() == otro.mesANumero() && dia < otro.dia)
      return true;
    if (mesANumero() == otro.mesANumero() && dia == otro.dia &&
        hora <= otro.hora)
      return true;
    return false;
  }

  // Sobrecarga del operador > para comparar fechas
  bool operator>(const Registro &otro) const {
    if (mesANumero() > otro.mesANumero())
      return true;
    if (mesANumero() == otro.mesANumero() && dia > otro.dia)
      return true;
    if (mesANumero() == otro.mesANumero() && dia == otro.dia &&
        hora > otro.hora)
      return true;
    return false;
  }
};

// Función para dividir una línea de texto en partes
vector<string> dividirLinea(string linea) {
  vector<string> partes;
  stringstream ss(linea);
  string item;
  while (ss >> item) {
    partes.push_back(item);
  }
  return partes;
}

// Leer archivo de bitácora y almacenar registros en un vector
vector<Registro> leerBitacora(string nombreArchivo) {
  ifstream archivo(nombreArchivo);
  vector<Registro> bitacora;
  string linea;

  while (getline(archivo, linea)) {
    vector<string> partes = dividirLinea(linea);
    if (partes.size() >= 5) {
      Registro reg = {partes[0], stoi(partes[1]), partes[2], partes[3],
                      partes[4]};
      bitacora.push_back(reg);
    }
  }
  archivo.close();
  return bitacora;
}

// Algoritmo de ordenamiento por inserción
void ordenarPorInsercion(vector<Registro> &bitacora) {
  int n = bitacora.size();
  for (int i = 1; i < n; i++) {
    Registro key = bitacora[i];
    int j = i - 1;

    // Mover los elementos mayores que key una posición adelante
    while (j >= 0 && bitacora[j] > key) {
      bitacora[j + 1] = bitacora[j];
      j--;
    }
    bitacora[j + 1] = key;
  }
}

// Guardar los registros en un archivo ordenado
void guardarBitacoraOrdenada(vector<Registro> bitacora, string nombreArchivo) {
  ofstream archivo(nombreArchivo);
  for (int i = 0; i < bitacora.size(); i++) {
    archivo << bitacora[i].mes << " " << bitacora[i].dia << " "
            << bitacora[i].hora << " " << bitacora[i].ip << " "
            << bitacora[i].razon << endl;
  }
  archivo.close();
}

// Función para solicitar fechas al usuario (pasa por referencia)
void solicitarFechas(string &fechaInicio, string &fechaFin) {
  cout << "Ingrese la fecha de inicio (formato: Mes Dia, ejemplo: Aug 1): ";
  getline(cin, fechaInicio);
  cout << "Ingrese la fecha de fin (formato: Mes Dia, ejemplo: Aug 31): ";
  getline(cin, fechaFin);
}

// Función de búsqueda binaria para encontrar el primer registro en el rango
int buscarInicio(vector<Registro> bitacora, Registro fechaInicio) {
  int izquierda = 0;
  int derecha = bitacora.size() - 1;
  while (izquierda <= derecha) {
    int medio = (izquierda + derecha) / 2;
    if (bitacora[medio] >= fechaInicio) {
      derecha = medio - 1;
    } else {
      izquierda = medio + 1;
    }
  }
  return izquierda;
}

// Función de búsqueda binaria para encontrar el último registro en el rango
int buscarFin(vector<Registro> bitacora, Registro fechaFin) {
  int izquierda = 0;
  int derecha = bitacora.size() - 1;
  while (izquierda <= derecha) {
    int medio = (izquierda + derecha) / 2;
    if (bitacora[medio] <= fechaFin) {
      izquierda = medio + 1;
    } else {
      derecha = medio - 1;
    }
  }
  return derecha;
}

// Función para mostrar registros en el rango de fechas
void mostrarRegistrosEnRango(vector<Registro> bitacora, string inicio,
                             string fin) {
  // Extraer el mes y el día de inicio y fin
  vector<string> partesInicio = dividirLinea(inicio);
  vector<string> partesFin = dividirLinea(fin);

  Registro fechaInicio = {partesInicio[0], stoi(partesInicio[1]), "", "", ""};
  Registro fechaFin = {partesFin[0], stoi(partesFin[1]), "", "", ""};

  // Buscar los índices usando búsqueda binaria
  int indiceInicio = buscarInicio(bitacora, fechaInicio);
  int indiceFin = buscarFin(bitacora, fechaFin);

  cout << "Registros entre " << inicio << " y " << fin << ":" << endl;

  // Imprimir los registros en el rango
  for (int i = indiceInicio; i <= indiceFin; i++) {
    cout << bitacora[i].mes << " " << bitacora[i].dia << " " << bitacora[i].hora
         << " " << bitacora[i].ip << " " << bitacora[i].razon << endl;
  }
}

int main() {
  // Leer bitácora
  vector<Registro> bitacora = leerBitacora("bitacora.txt");

  // Ordenar la bitácora por inserción
  ordenarPorInsercion(bitacora);

  // Guardar bitácora ordenada
  guardarBitacoraOrdenada(bitacora, "bitacora_2.txt");

  // Solicitar fechas al usuario
  string fechaInicio, fechaFin;
  solicitarFechas(fechaInicio, fechaFin);

  // Mostrar registros en el rango de fechas
  mostrarRegistrosEnRango(bitacora, fechaInicio, fechaFin);

  return 0;
}